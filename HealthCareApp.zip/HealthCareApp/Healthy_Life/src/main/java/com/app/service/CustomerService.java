package com.app.service;

import java.time.LocalDate;
import java.util.List;

import com.app.pojos.Customer;

public interface CustomerService {

	List<Customer> getAllCustDetails();

	Customer addCustDetails(Customer transientProd);

	String deleteCustDetails(Long CustId);

	Customer fetchCustDetails(Long CustId);

	Customer updateCustDetails(Customer detachedCust);

}
