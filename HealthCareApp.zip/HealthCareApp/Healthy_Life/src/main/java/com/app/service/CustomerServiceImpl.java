package com.app.service;

import java.util.List;

import javax.annotation.PostConstruct;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.pojos.Customer;
import com.app.repository.CustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository custRepo;
	
	@Autowired
	private ModelMapper mapper;

	@PostConstruct
	public void init() {
		System.out.println("in init " + mapper);
	}

	@Override
	public 	List<Customer> getAllCustDetails() {
		return custRepo.findAll();
	}

	@Override
	public Customer addCustDetails(Customer transientProd) {
		// TODO Auto-generated method stub
		return custRepo.save(transientProd);
	}

	@Override
	public String deleteCustDetails(Long CustId) {
		if (custRepo.existsById(CustId)) {
			custRepo.deleteById(CustId);
			return "Emp details deleted ....";
		}
		return "Deletion Failed : Invalid Emp Id !!!!!!!!!!!";
	}

	@Override
	public Customer fetchCustDetails(Long CustId) {
		// TODO Auto-generated method stub
		return custRepo.findById(CustId).orElseThrow(() -> new ResourceNotFoundException("Invalid Product not found !!!!!"));
	}

	@Override
	public Customer updateCustDetails(Customer detachedCust) {
		if (custRepo.existsById(detachedCust.getId())) {
			return custRepo.save(detachedCust);
		}
		throw new ResourceNotFoundException("Invalid Emp Id : Updation Failed!!!!!!!!");
	}

}
