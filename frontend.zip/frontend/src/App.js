import { BrowserRouter, Switch, Route } from 'react-router-dom';
import Nutrition from './components/Nutrition';
import HealthyAging from './components/HealthyAging';
import HealthyTips from './components/HealthyTips';
import HealthyDiet from './components/HealthyDiet';
import MedicalTest from './components/MedicalTest';
import HappyAndHealthyLIfe from './components/HappyAndHealthyLIfe';
import NotFound from './components/NotFound';
import 'bootstrap/dist/css/bootstrap.min.css';
import AddCustomer from './components/Customer/AddCustomer';
import CustomerList from './components/Customer/CustomerList';
import NavbarComponent from './components/navbar/NavbarComponent';

function App() {
  return (
    <BrowserRouter>
      <div>
        <div>
          <Switch>
          {/* <HomePage/> */}
          <Route exact path="/" component={NavbarComponent} />
          {/* Registration form */}
          <Route exact path="/RegistrationForm" component={AddCustomer} />
          {/* Customer DashBoard */}
          <Route exact path="/customer" component={CustomerList} />

          {/* Affiliated links */}
          <Route exact path="/Nutrition" component={Nutrition} />
          <Route exact path="/HealthyAging" component={HealthyAging} />

          <Route exact path="/HealthyTips" component={HealthyTips} />
          <Route exact path="/HealthyDiet" component={HealthyDiet} />
          
          <Route exact path="/HappyAndHealthyLIfe" component={HappyAndHealthyLIfe} />
          <Route exact path="/MedicalTest" component={MedicalTest} />
          
          <Route path="*" component={NotFound} />
          </Switch>
        </div>
      </div>
    </BrowserRouter>
  );
}


export default App;
