import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import customerService from '../../services/customer.service';
import '../../css/customerList.css';


const CustomerList = () => {
  const [customer, setCustomer] = useState([]);
  // const [tempEmp, setTempemp] = useState([]);

  const init = () => {
    customerService
      .getAll()
      .then((response) => {
        console.log('Printing customer data', response.data);
        setCustomer(response.data);
        // setTempemp(response.data);
        console.warn(response.data);
      })
      .catch((error) => {
        console.log('Something went wrong', error);
      });
  };

  useEffect(() => {
    init();
  }, []);

  const handleDelete = (id) => {
    console.log('Printing id', id);
    customerService
      .remove(id)
      .then((response) => {
        console.log('customer deleted successfully', response.data);
        init();
      })
      .catch((error) => {
        console.log('Something went wrong', error);
      });
  };

  return (
    <div className='customerDiv'>
      <div className='container'>
        <h3 align="center">Customer Dashboard</h3>
        <hr />
        <div>
          {/* <Link to='/addc' className='btn btn-primary mb-2'>
            Add Customer
          </Link> */}
          <table className='table table-bordered table-striped'>
            <thead className='thead-dark'>
              <tr>
                <th>Name</th>
                <th>Mobile</th>
                <th>Address</th>
                <th>Age</th>
                <th>Disease</th>
                <th>Food Intake/day(Kcal)</th>
                <th>Sleep hours/day</th>
                <th>Water Intake/day</th>
                <th>Weight(in kg)</th>
                <th>Height(in cm)</th>
                <th>Excercise(Yes/No)</th>
                <th colSpan={3}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {customer.map((customer) => (
                <tr key={customer.id}>
                  <td>{customer.customerName}</td>
                  <td>{customer.customerMobile}</td>
                  <td>{customer.customerAddr}</td>
                  <td>{customer.customerAge}</td>
                  <td>{customer.disease}</td>
                  <td>{customer.food}</td>
                  <td>{customer.sleephours}</td>
                  <td>{customer.bodyWeight}</td>
                  <td>{customer.height}</td>
                  <td>{customer.waterIntake}</td>
                  <td>{customer.activity}</td>
                  {/* Added Delete button just for testing purpose */}
                  <td>
                    <button
                      className='btn btn-danger ml-2'
                      onClick={() => {
                        handleDelete(customer.id);
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <hr />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <div>
          <div>

            <h3><Link style={{ color: 'black' }} to='/HappyAndHealthyLIfe'>&diams; Ways to Live a Happy and Healthy Life During Old Age</Link></h3>
          </div>
          <div>
            <h3><Link style={{ color: 'black' }} to='/Nutrition'>&diams; Nutrition needs when you're 65 above</Link></h3>
          </div>
          <div>
            <h3><Link style={{ color: 'black' }} to='/HealthyAging'>&diams; What Do We Know About Healthy Aging?</Link></h3>
          </div>
          <div>
            <h3> <Link style={{ color: 'black' }} to='/HealthyTips'>&diams; Healthy Aging Tips for the Older Adults in Your Life</Link></h3>
          </div>
          <div>
            <h3><Link style={{ color: 'black' }} to='/HealthyDiet'>&diams; A healthy diet for those aged 65 and beyond</Link></h3>
          </div>
          <div>
            <h3><Link style={{ color: 'black' }} to='/MedicalTest'>&diams; A medical test checklist</Link></h3>
          </div>
        </div>
        <div>
          <Link to='/'>Back to HomePage</Link>

        </div>
      </div>
    </div>
  );
};

export default CustomerList;
