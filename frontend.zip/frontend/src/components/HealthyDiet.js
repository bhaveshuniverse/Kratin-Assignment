import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../css/healthCare.css';


const HealthyDiet = () => {
  return (
    <div className='employeeDiv'>
      <div className='container'>
        <h1 id='top'>A healthy diet for those aged 65 and beyond</h1>
        <hr />
        <div id="main">
          <p>
            One of the inevitable aspects about life is constant change and our nutritional needs are no different – they change over time too. Whatever your age, it's important to eat a varied and balanced diet, full of vegetables and fruit, high quality protein, starchy carbs, fibre and healthy fats. After the age of 65, it can be useful to pay a little more attention to how as well as what you eat – read on to discover more.
          </p>
          <h3>On this page</h3>
          <h5>
            <a href='#link1'>1. Enjoy meals</a>
            <br />
            <a href='#link2'>2. Eat a varied daily diet</a>
            <br />
            <a href='#link3'>3. Vital vitamin D</a>
            <br />
            <a href='#link4'>4. B12 for energy</a>
            <br />
            <a href='#link5'>5. Power up on protein</a>
            <br />
            <a href='#link6'>6. Be salt savvy</a>
            <br />
            <a href='#link7'>7. Fill up on fibre</a>
            <br />
            <a href='#link8'>8. Stay hydrated</a>
            <br />
            <a href='#link9'>9. Be weight-wise</a>
            <br />
            <a href='#link10'>10. Keep active</a>
            <br />
          </h5>
          <br />

          <h2>1. Enjoy meals</h2>
          <section>
            Make meals more positive – even if you are eating alone, a nicely laid table can make all the difference. Or, encourage a friend or neighbour to eat with you. If your appetite is less than it used to be try four smaller meals rather than the traditional three. Spreading your food intake throughout the day with smaller meals and regular snacks is useful if you find it uncomfortable to eat a lot in one sitting.
            <br /><br />
          </section>
          <br />
          <section id='link2'>
            <h2>2. Eat a varied daily diet</h2>
            <p>Registered nutritionist, Jo Lewin says, "Various physiological and psychological changes occur as we age, these affect our nutritional requirements. In addition to this, our body becomes less efficient at absorbing and using vitamins and minerals. Long-term use of prescription drugs may also reduce nutrient absorption and at the same time, our appetite may decrease. As the need for vitamins and minerals stays the same, or in some cases increases, it becomes even more important that the food we eat is healthy and nutritious."<br /><br />

              For this reason, aim to eat a balanced and varied diet, containing at least five portions of fruit and vegetables each day. If cooking fresh fruit and vegetables is an issue, canned or frozen vegetables can be a great alternative – they are easier to prepare, cost effective and in many cases just as nutritious.<br /><br />

              When buying canned produce, choose those packed in natural juice or water, without added sugar or salt. You can also include a 30g portion of dried fruit and a 150ml portion of fruit juice or smoothies once a day, ideally eaten at mealtimes, rather than in between (to reduce the risk of tooth decay). Canned and dried forms of fruit and vegetables are great storecupboard staples, making them especially handy if it is difficult to get to the shops.<br /><br />
            </p>
          </section>
          <section id='link3'>
            <h2>3. Vital vitamin D</h2>
            <p>
              Vitamin D is made by the reaction of sunlight on the skin, so if possible, get out in the sun for at least 20 minutes a day without sunscreen (although if you are out for longer than this, do take the appropriate steps to protect your skin from sun damage).<br /><br />

              During the autumn and winter months the sun is not strong enough for the body to make vitamin D, so diet is important. Foods like eggs and oily fish (such as salmon, sardines and mackerel) along with fortified foods such as some spreads and breakfast cereals, are good sources. If you are over 65 you are advised to take a daily supplement of 10 micrograms of vitamin D – this is also relevant for adults for whom access to safe sunlight is limited.<br /><br />

              Speak to your GP for more information and discover more about vitamin D.
            </p>
          </section>
          <section id='link4'>
            <h2>4. B12 for energy</h2>
            <p>
              Vitamin B12 is important for many processes in the body, including producing red blood cells, maintaining the nervous system and releasing energy from food. As we age, our ability to absorb this vitamin becomes less effective, so maintaining an adequate intake is key. Foods that are rich sources include liver, mackerel, fortified soya milk, yogurt, most meats, salmon, cod, milk, cheese, eggs and fortified breakfast cereals.<br /><br />
            </p>
          </section>
          <section id='link5'>
            <h2>5. Power up on protein</h2>
            <p>
              We need protein to build and maintain tissue, cells and muscle, make hormones and produce antibodies. Studies suggest that as we get older we may benefit from eating more protein because it helps minimise the muscle loss associated with aging.<br /><br />

              High-quality protein includes meat such as beef and pork, poultry such as chicken and turkey, fish such as salmon and cod, and seafood including prawns. Dairy products like milk, cheese and yogurt are suitable sources for vegetarians, while vegan sources include beans, nuts, seeds, quinoa, soya and tofu.<br /><br />
              Read more about the best sources of protein, including vegetarian and vegan sources.<br /><br />
            </p>
          </section>
          <section id='link6'>
            <h2>6. Be salt savvy</h2>
            <p>
              Including some salt is important for health, but eating too many pre-packaged foods may mean you consume too much. Our sense of smell and taste may become less acute as we get older, and it can be tempting to add extra salt to our food to compensate. Instead, flavour food with herbs, spices and other strongly flavoured ingredients like garlic, lemon juice, vinegar or mustard<br /><br />

              Read more about low-salt diets.<br /><br />
            </p>
          </section>
          <section id='link7'>
            <h2>7. Fill up on fibre</h2>
            <p>
              Including fibre in your diet helps to keep your digestive system healthy and promote regular bowel movements. Make sure your diet includes a wide variety of fibre-rich foods such as wholegrains, oats, fruits, vegetables, beans and lentils. A small glass of prune juice in the morning may help alleviate constipation.<br /><br />

              If you're taking medication, talk to your GP before significantly increasing your fibre or taking fibre supplements. This is because fibre slows down digestion and may decrease the rate at which your medication is absorbed. Similarly, if your intake of fibre in your diet has always been on the low side – increase it gradually, giving your digestive system plenty of time to adapt to this change. Refer to a dietician for guidance if needed.<br /><br />
            </p>
          </section>
          <section id='link8'>
            <h2>8. Stay hydrated</h2>
            <p>
              It can be easy to forget to drink enough water, but it's important to aim for around 6-8 glasses or cups a day. The good news is this doesn't all have to be plain water – milk, sugar-free drinks and tea and coffee all count, but do bear in mind that caffeinated drinks can make the body produce urine more quickly.<br /><br />

              Fruit juice and smoothies also count, but because they contain ‘free’ sugars (the type we are encouraged to cut back on), you should limit these to a combined total of 150ml per day.<br /><br />

              Many of the foods we eat contribute to our fluid intake – examples include soup, ice cream and jelly, as well as certain fruit and vegetables like melon, courgette or cucumber.<br /><br />
              Discover how much water you should drink each day and the health benefits of drinking water.<br /><br />
            </p>
          </section>
          <section id='link9'>
            <h2>9. Be weight-wise</h2>
            <p>
              The number of calories that your body needs may change as you get older, and depends on a wide range of factors, including your activity levels and metabolism. Eating too many calories may lead to weight gain, while eating too few may lead to weight loss. The NHS have a useful online BMI healthy weight calculator – take a look if you're not sure if your weight is in the healthy range.<br /><br />

              Keeping weight up can be a challenge for some older people, due to illness or a loss of appetite. It's important to maintain a healthy body weight in order to keep bones healthy, support the immune system and reduce the risk of nutritional deficiencies. If you're underweight or have unintentionally lost weight, speak to your GP to ensure there is no underlying medical reason for the weight loss.<br /><br />
              If you need to boost your calorie intake to keep your weight up, try including healthy, high-energy meals and snacks. Make the most of high-calorie ingredients such as avocado, peanut butter, dried fruit, nuts, cheese and full-fat milk.<br /><br />
            </p>
          </section>
          <section id='link10'>
            <h2>10. Keep active</h2>
            <p>
              Exercise has a huge range of health benefits for all ages – and the good news is that any physical activity counts. If you're over 65 and are able, the NHS recommends some physical activity every day – this might include strengthening and flexibility exercises on two days each week (such as carrying heavy shopping bags or yoga); 150 minutes of moderate intensity activity (such as brisk walking or riding a bike) or 75 minutes of vigorous intensity activity (such as jogging, running or playing tennis).<br /><br />

              Wheelchair users or those with limited mobility may benefit from sitting exercises, swimming and strengthening exercises using equipment such as resistance bands.<br /><br />
              If you are unable to leave home for whatever reason, housework and light gardening are great for maintaining the mobility of joints and muscles. Chair yoga may have a positive effect on mind and body, and requires little space or equipment.<br /><br />
              The reason exercise is so important for older adults, is because muscles and bones naturally lose strength with age. Staying active can help to maintain strength, reduce the risk of osteoporosis, and improve balance, whilst reducing the risk of hip fractures and falls. If you’ve been diagnosed with osteoporosis, the NHS advice is to stay active<br /><br />
              If you have experienced a recent fracture, have blood pressure issues or any other medical condition, please check with your GP or health practitioner to ensure the exercise is appropriate for you.<br /><br />
            </p>
          </section>
        </div>
        <div align="right"> <a href='#top'>Go to top</a></div>
        <div>
          <Link to='/customer'>Back to Dash Board</Link>
        </div>
      </div>
    </div>

  );
};

export default HealthyDiet;
