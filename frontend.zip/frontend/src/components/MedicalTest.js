import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../css/healthCare.css';


const MedicalTest = () => {
    return (
        <div className='employeeDiv'>
            <div className='container'>
                <h1 id='top'>A medical test checklist </h1>
                <hr />
                <div id="main">
                    <p>
                        <b>Prevention is better than cure. Here are some must-take tests to ensure that all is well</b><br></br>
                        A stitch at time saves nine. That’s applicable to preventing non-communicable conditions ranging from diabetes to cardiovascular risks to obesity. For example, a check of fasting blood sugar can find out if there are any borderline diabetes issue and a lipid profile test can point out cholesterol levels.<br></br>

                        Doctors across specialisations say a periodic check-up of key parameters can help in arresting the progression of an organ malfunction or metabolic disturbance.
                        <br></br>
                    </p>
                    <h3><b>Happiest Health</b> lists out some must-take tests </h3>
                    <h5>
                        <a href='#link1'>1. Know your sugar levels</a>
                        <br />
                        <a href='#link2'>2. For overall health, cholesterol, thyroid gland</a>
                        <br />
                        <a href='#link3'>3. For cardiac health</a>
                        <br />
                        <a href='#link4'>4. General tests</a>
                        <br />
                        <a href='#link5'>5. For smokers and drinkers</a>
                        <br />
                        <a href='#link6'>6. For women’s health</a>
                        <br />
                    </h5>
                    <br />

                    <h2>1. Know your sugar levels</h2>
                    <section>
                        <br></br>
                        <ul>
                            <li>
                                <b>Haemoglobin A1c (HbA1c) test:</b> This is a commonly given blood test which measures the average blood sugar level over the past two to three months. It should be taken every year.
                            </li>
                            <br></br>
                            <li>
                                <b>Fasting blood sugar test: A blood test to measure the basal sugar levels of blood, it is usually done in the morning after long hours of overnight fasting.</b>
                            </li> <br></br>
                            <li>
                                <b>Postprandial blood sugar test:</b> Refers to blood sugar levels measured two hours after eating. Levels of 99mg/dL or lower are normal, 100 to 125mg/dL indicate you have prediabetes, and 126mg/dL or higher suggest you have diabetes
                            </li>
                        </ul>
                        <br /><br />
                    </section>
                    <br />
                    <section id='link2'>
                        <h2>2. For overall health, cholesterol, thyroid gland</h2>
                        <br></br>
                        <p>
                            <ul>
                                <li>
                                    <b>Complete blood count (CBC):</b> This blood test is used to evaluate overall health and detect a wide range of disorders, including anemia, infection and leukemia. It should be taken once a year after the age of 30.
                                </li> <br></br>
                                <li>
                                    <b>Lipid profile:</b> This is a blood test that measures total cholesterol — ‘good’ HDL cholesterol, ‘bad’ LDL cholesterol and triglycerides (a kind of fat in the blood). Testing once in two years is advised for those with normal readings.
                                </li> <br></br>
                                <li>
                                    <b>Thyroid function tests (TFTs):</b>  A group of tests to evaluate the functioning of the thyroid gland and its hormones, TFTs are helpful in diagnosing thyroid disorders.
                                </li> <br></br>
                            </ul>
                        </p>
                    </section>
                    <section id='link3'>
                        <h2>3. For cardiac health</h2>
                        <br></br>
                        <p>
                            <ul>
                                <li>
                                    <b>Blood pressure test:</b> A blood pressure test is performed to measure the strength with which blood pushes on the walls of arteries. A reading below 120/80mm Hg is ideal. If the reading is normal, the test can be repeated after a year.
                                </li> <br></br>
                                <li>
                                    <b>ECG (Electrocardiogram):</b> Measures electrical activity of the heart to detect cardiac problems. It must be taken annually after the age of 35.
                                </li> <br></br>
                                <li>
                                    <b>TMT (Treadmill test):</b> Both men and women are advised to take a TMT to detect cardiac-related issues after the age of 30.
                                </li> <br></br>
                                <li>
                                    <b>Stress echocardiogram (or stress echo):</b> A radioactive substance (a tracer) is injected into the bloodstream. The stress echo uses an ultrasound to detect differences in the heart’s chambers and valves, and how strongly the heart beats when exercised or when stressed after having a medicine.
                                </li> <br></br>
                            </ul>
                        </p>
                    </section>
                    <section id='link4'>
                        <h2>4. General tests</h2>
                        <br></br>
                        <p>
                            <ul>
                                <li>
                                    <b>Prostate-specific antigen (PSA) test: </b>A blood test used to screen for prostate cancer, it measures the amount of PSA in the blood.
                                </li> <br></br>
                                <li>
                                    <b>Bone mineral density test: </b>Osteoporosis occurs when bones lose minerals such as calcium more quickly than the body can replace them. As a result, the bones lose density and strength, and break more easily. Though osteoporosis is commonly seen among women, the test is advised for men with advancing age too.
                                </li> <br></br>
                                <li>
                                    <b>Screening for sexually transmitted infections (STIs):</b> Those having multiple sexual partners and those planning to conceive are advised to check for STIs such as syphilis, gonorrhea, HIV, hepatitis B and C.
                                </li> <br></br>
                            </ul>
                            <br /><br />
                        </p>
                    </section>
                    <section id='link5'>
                        <h2>5. For smokers and drinkers</h2>
                        <br></br>
                        <p>
                            <ul>
                                <li>
                                    <b>Spirometry:</b> This is one of the most important tests for smokers. Vital capacity measurement is a special type of breath test done with a chest X-ray. This primary test is usually done to measure how effectively the lungs are functioning and to rule out the possibility of lung cancer, pulmonary fibrosis, esophageal cancer and other interstitial lung diseases, says Dr Arpan Chaudhuri, internal medicine, Manipal Hospitals, Salt Lake, Kolkata.
                                </li> <br></br>
                                <li>
                                    <b>Pulmonary function test:</b> In this simple breath test, the patient breathes in and inhales into the machine to see how much air goes in and out of the lungs. Dr Chaudhuri says that the test is especially helpful for those with a history of smoking.
                                </li> <br></br>
                                <li>
                                    <b>CT scan:</b> Low-dose computer tomography, or CT scan, can help detect problems such as lung cancer. Chain smokers should not miss a CT scan. These scans provide better diagnostic images and allow doctors to detect complications such as lung cancer earlier than plain X-rays.
                                </li> <br></br>
                                <li>
                                    <b>Liver function test:</b> A blood test used to help diagnose and monitor liver disease or damage. It must be done annually to screen for liver conditions, such as alcohol-induced liver damage, fatty liver, hepatitis C and B.
                                </li> <br></br>
                                <li>
                                    <b>Urine analysis:</b> Checks for presence of proteins, sugar and blood (especially in smokers at high risk for bladder cancer) in the urine sample, which could indicate kidney disease, among other conditions.
                                </li> <br></br>
                            </ul>
                        </p>
                    </section>
                    <section id='link6'>
                        <h2>6. For women’s health</h2>
                        <br></br>
                        <p>
                            Dr Chaudhuri says if there is any specific gynecological problem, certain separate tests such as Papanicolaou (Pap) test and human papillomavirus (HPV) test can help to identify the issues.
                            <ul>
                                <li>
                                <b> Papanicolaou (Pap) test: </b>A procedure to test for cervical cancer in women which involves collecting cells from the cervix — the lower, narrow end of the uterus that is at the top of the vagina.</li> <br></br>

                                    <li><b>Human papillomavirus (HPV) test:</b>  This is conducted to detect the presence of human papillomavirus, which can lead to the development of genital warts, abnormal cervical cells or cervical cancer. It helps in the prevention of cervical cancer in women over the age of 30.</li> <br></br>

                                    <li><b>Mammogram:</b>  An X-ray imaging to detect for the presence of a tumor or lump in the breast. The test helps in identifying cysts, calcifications and tumors. It is advisable to do a bilateral mammogram to screen for breast cancer after the age of 40.</li> <br></br>

                                    <li><b>Calcium and vitamin D blood test:</b>  Women could be more prone to osteoporosis post-menopause. These two tests help in determining any deficiency. They are recommended for women over the age of 40, says Dr Joshi.</li> <br></br>

                                    <li><b>Bone mineral density test:</b>  Post-menopausal women need to take this test to measure bone strength. It calculates the density of minerals (especially calcium) in the bone using X-rays or CT scan.
                                </li> <br></br>
                            </ul>
                        </p>
                    </section>
                   
                </div>
                <div align="right"> <a href='#top'>Go to top</a></div>
                <div>
                    <Link to='/customer'>Back to Dash Board</Link>
                </div>
            </div>
        </div>

    );
};

export default MedicalTest;
