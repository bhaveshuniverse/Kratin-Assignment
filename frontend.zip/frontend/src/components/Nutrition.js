import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../css/healthCare.css';


const Nutrition = () => {
  return (
    <div className='employeeDiv'>
      <div className='container'>
        <h1 id="top">Nutrition needs when you’re over 65</h1>
        <hr />
        <div>
          <h3>On this page</h3>
          <h4>
            <a href='#link1'>1. What to put on your plate when you’re over 65</a>
            <br />
            <a href='#link2'>2. How much to put on your plate when you’re over 65</a>
            <br />
            <a href='#link3'>3. The importance of healthy meals when you’re over 65</a>
            <br />
            <a href='#link4'>4. How to make quick and simple meals</a>
            <br />
            <a href='#link5'>5. Remember…</a>
            <br />
            <a href='#link6'>6. Where to get help</a>
          </h4>
          <br />
          <section>
            Nutrition needs vary with age and gender. Now you’re older, the foods and drinks that make up a healthy diet may need to be slightly different from when you were younger. In general, you’ll need less of some foods and more of others.
            <br /><br />
            How you eat as an older person will also vary depending on your gender: older men have different nutritional needs from older women.
            <br /><br />
            But healthy eating doesn’t really change that much with age, especially if you already have a good diet. You simply need to be aware of your own specific nutrition requirements and adjust your food choices so your body gets exactly what it needs for good health in older age.
            <br /><br />
            If you need help choosing or preparing a healthy diet, chat to a family member, your healthcare professional, carer or an Accredited Practising Dietitian.
            <br />
            Discuss any major change in eating or exercise patterns with your doctor, pharmacist and dietitian. Any medications you take may need to be adjusted.
          </section>
          <br />
          <h2>1. What to put on your plate when you’re over 65</h2>
          <section>
            The best place to start for any person looking to develop a healthy diet is the Australian Dietary Guidelines. The guidelines were developed by the National Health and Medical Research Council, with input from many food and nutrition experts, as well as members of the community.
            <br /><br />
            They are based on the best available science about the types and amounts of foods and dietary patterns that may promote health and wellbeing, and reduce the risk of diet-related conditions and chronic disease.
            <br /><br />
            You probably know a healthy diet benefits you physically, mentally and socially. Without good food and drink choices, you’re at greater risk of chronic diseases, such as cardiovascular disease, type 2 diabetes, some cancers, and even mental health issues, such as anxiety and depression. A healthy diet helps socially too – regularly connecting with other people may stave off loneliness and isolation.
            <br /><br />
            <h5>So, what do the guidelines say? In a nutshell, they advise every Australian to:</h5>
            <br />
            &diams; Eat a wide variety of foods from the five food groups: plenty of colourful vegetables, legumes/beans; fruit; grain (cereal) foods, mostly wholegrain and high fibre varieties; lean meats and poultry, fish, eggs, tofu, nuts and seeds; milk, yoghurt, cheese or their alternatives, mostly reduced fat.
            <br /><br />
            &diams; Drink plenty of water – six to eight cups of fluid per day.
            <br /><br />
            Limit foods high in saturated fat, such as biscuits, cakes, pastries, pies, processed meats, commercial burgers, pizza, fried foods, potato chips, crisps and other savoury snacks.
            <br /><br />
            &diams; Replace high fat foods containing mostly saturated fat with foods containing mostly polyunsaturated and monounsaturated fats. Swap butter, cream, cooking margarine, coconut and palm oil with unsaturated fats from oils, spreads, nut butters and pastes, and avocado.
            <br /><br />
            &diams; Limit foods and drinks containing added salt, and don’t add salt to foods in cooking or at the table.
            Limit foods and drinks containing added sugars, such as confectionery, sugar-sweetened soft drinks and cordials, fruit drinks, vitamin waters, energy and sports drinks.
            <br /><br />
            &diams; Limit alcohol. (Drink no more than two standard drinks a day.)
            <br /><br />
            &diams; Keep ‘extras’ or ‘sometimes foods’ to a minimum – they’re not a regular part of a healthy diet. Extras are the high sugar, high fat, high salt foods listed above, such as commercial burgers, pizza, alcohol, lollies, cakes and biscuits, fried foods, and fruit juices and cordials.
            <br /><br />
            &diams; Be physically active. (Aim for at least 30 minutes of moderate intensity physical activity, such as walking, every day.)
            <br /><br />
            <h5>Extra specific advice for older people includes:</h5>
            <br />
            &diams; Maintain healthy weight and muscle strength through physical activity. The benefits of walking for older people]. It’s been shown people over 65 years often have better health if they carry a little extra weight and have a slightly higher body mass index. Talk to your healthcare professional if you need to lose or gain weight.
            <br /><br />
            &diams; If you’re on a budget, simply do your best with your food choices. Plan well, use what’s available, and buy only what you need. Look out for quick and easy healthy recipes for one or two people, and try to eat regularly with family and friends if possible.
            <br /><br />
            &diams; Be careful with your teeth. If nuts, grains and hard fruits and vegetables are difficult to chew, try milled wholegrains, soft cooked and canned fruits and vegetables, and nut pastes and butters.
            <br /><br />
            &diams; Prepare and store food safely. Follow food safety guidelines to avoid food-borne illnesses which can be particularly bad for older people.
            <br /><br />
            &diams; Limit your intake of foods containing saturated fats and trans fats. Remember those ‘extras’ or ‘sometimes foods’ referred to in the guidelines? Keep those to a minimum. Foods like pies, pastries, fried and battered foods, chips, and chocolate are generally high in saturated fat, and may contain dangerous trans fats. Eat these foods very occasionally. Fresh fruit with reduced fat yoghurt is a good dessert option, or cakes and crumbles made with wholegrain options, like oats.
            <br /><br />
            &diams; Talk to your doctor about your personal health needs, particularly about how best to apply the dietary guideline that says to limit saturated fats, added salt, and added sugars (above). Some older people may be at risk of malnutrition from restricting their food intake, and eat too few nutrients and kilojoules for their age.
            <br /><br />
            &diams; Eat plenty of fibre and drink plenty of fluids. Water is essential for hydration, digestion and blood volume, but now you’re older, you may not feel as thirsty as you once did, even when your body needs fluids. Try to drink water about 6–8 cups of fluid a day, and more in warmer weather or when exercising. Water is your best bet for hydration, but tea, coffee, mineral and soda water, and reduced fat milk count too. High fibre foods and plenty of fluids will help to move slow bowels.
            <br /><br />
            &diams; Use less salt. Everyone needs some salt, but too much can increase your risk of high blood pressure and heart disease. Watch your intake of high salt foods, such as cured meats (ham, corned beef, bacon, lunch meats etc.), snack foods (potato chips and savoury pastries etc.), and sauces (soy sauce, for example). Choose reduced salt food when shopping, and flavour your cooking with herbs and spices instead of salt.
            <br /><br />
            &diams; Watch your alcohol intake. Follow Australian guidelines if you drink: no more than two standard drinks on any given day for healthy men and women.
            <br /><br />
            &diams; Get your vitamins and minerals. If you eat less or have digestive issues, you may be deficient in some important vitamins and minerals. Speak to your doctor about your levels, and always choose a variety of foods from the five food groups.
            Fish is your friend. Regularly consuming fish may reduce your risk of heart disease, stroke, dementia, and macular degeneration (a type of vision loss). Eating fish twice a week is wise.
            <br /><br />
            You may like to check how healthy your existing diet is using this Healthy Eating Quiz from the Dietitians Association of Australia.
            <br /><br />
          </section>
          <br />
          <section id='link2'>
            <h2>2. How much to put on your plate when you’re over 65</h2>
            <br />
            <p>Throughout life, men generally need more energy (calories or kilojoules) per day than women. This is because men tend to be larger and have a higher proportion of muscle.
              <br /><br />
              The amount of energy you need each day depends on your age, height, and how active you are. But as you tend to lose muscle mass, and activity levels tend to drop with age, kilojoules also need to reduce. This doesn’t mean you need fewer nutrients. In fact, your need for nutrients (carbohydrates, fat, protein, vitamins, minerals, fibre, water, etc.) will remain roughly the same, if not go up.
              <br /><br />
              Calcium is a good example. Your need for calcium for strong bones and teeth will increase, so extra serves of low fat milk, yoghurt and cheese are important. Other good sources of calcium are tinned salmon, sardines, leafy greens like spinach, kale and bok choy, sesame seeds (and tahini) and almonds.
              <br /><br />
              Serving sizes and amounts
              When it comes to meals, it’s good to know serving sizes and how much you need for your age. For the five food groups, aim for these serves each day :
              <br /><br />
              <h5>Serving sizes for each food group are:</h5>
              <br />
              <b>&diams; vegetables:</b> a standard serve is about 75 grams (100–350 kilojoules); for example, ½ cup cooked green or orange vegetables or ½ cup cooked dried or canned beans, peas or lentils
              <br /><br />
              <b>&diams; fruit:</b> a standard serve is 150 grams (350 kilojoules); for example, a medium apple or banana, or two kiwifruits or plums. Try to eat whole fruit and not fruit juice
              <br /><br />
              <b>&diams; grain foods:</b> a standard serve is 500 kilojoules; for example, one slice of bread or ½ cup cooked porridge. At least two-thirds of choices should be wholegrain varieties
              <br /><br />
              <b>&diams; lean meats and poultry, fish, eggs, tofu, nuts and seeds, and legumes/beans:</b> a standard serve is 500–600 kilojoules; for example, 65 grams cooked lean red meats or two large eggs
              <br /><br />
              <b>&diams; milk, yoghurt and cheese or alternatives:</b> a standard serve is 500–600 kilojoules; for example, a cup of milk or ¾ cup yoghurt.
              <br /><br />
              More information about serving sizes and food examples can be found in this healthy eating summary guide.</p>
          </section>
          <br />
          <section id='link3'>
            <h2>3. The importance of healthy meals when you’re over 65</h2>
            <br />
            <p>
              Now you’re older, you may find it difficult to get out to buy groceries, or you may feel like your appetite has reduced or disappeared. Health issues may also make it difficult to eat or enjoy foods.
              <br /><br />
              If you can, try to see every meal and snack as a chance to give your body maximum nutrition (like vitamins, minerals and fibre) – and as a social activity you can enjoy with others if possible.
              <br /><br />
              Ask for help with shopping or meal preparation, if you need it, from family and friends, community groups, carers, or your doctor.
              <br /><br />
              Keep the following health matters in mind too.
              <br /><br />
              <h4>Healthy bones and teeth</h4>
              <br />
              If you’re on bed rest or not exercising much, you may experience muscle loss, which can increase your risk of falls and broken bones. Protein is essential for building, repairing, and maintaining healthy bones and muscles.
              <br /><br />
              Excellent sources of protein include all meats, fish, eggs, and seafood; all types of dairy (watch cream and butter intake); and soy products like tofu and soy beverages. Other good sources include beans and pulses, such as baked beans, all nuts and seeds, and wholegrains.
              <br /><br />
              Try to spread your protein intake across the day so your body has the chance to use it while you’re busy, rather than saving it all until your evening meal when the body doesn’t need it as much. If you’re not very hungry, try to eat the protein part of your meal first.
              <br /><br />
              <h5>You may like to try these meal ideas for a protein boost:</h5>
              <br />
              <b>&diams; breakfast:</b> add yoghurt and milk to cereal; or try egg, sardines, leftover meat or cheese on toast
              <br /><br />
              <b>&diams; lunch:</b> have some cheese or ham; make an open sandwich of tinned tuna or sardines; have a glass of milk or a banana smoothie
              <br /><br />
              <b>&diams; dinner:</b> serve meat, chicken, fish or eggs with vegetables like broccoli or cauliflower with melted cheese; enjoy ice-cream, yoghurt or custard with fruit for dessert.
              <br /><br />
              Vitamin D is also essential for healthy bones. The best source is the sun, but you only need a short time in the sunshine each day to get the amount of vitamin D you need. Aim for 10 to 30 minutes if you live in Australia, but check on healthy amounts for you in your area.
              <br /><br />
              If you’ve been advised by your doctor to stay out of the sun, you can also get vitamin D from egg yolk, butter, table margarine, whole milk, yoghurt, cheese, malted milk, lamb's fry, liver, tuna, sardines and pilchards or a supplement. Talk to your doctor about your needs.
              <br /><br />
              Weight-bearing exercise, such as walking or light weights, is also important for bone health.
              <br /><br />
              <h4>Arthritis</h4>
              <br />
              If you suffer from arthritis, fish oil may help. Eat fish at least twice a week, or talk to your doctor about a supplement.
              <br /><br />
              <h4>Healthy bowels</h4>
              <br />
              To keep your bowels active, include plenty of fibre in your diet. Wholegrain cereals, wholemeal bread, fruit, dried fruit, dried peas, beans and lentils are all excellent sources. Make sure you drink enough water to prevent constipation. Remember, most older people need 6–8 cups of fluid each day.
              <br /><br />
              <h4>Healthy teeth</h4>
              <br />
              Have your teeth or dentures checked regularly so you can continue to enjoy a wide variety of foods. See your dentist whenever you are having difficulty with your teeth, gums or dentures.
            </p>
          </section>
          <br />
          <section id='link4'>
            <h2>4. How to make quick and simple meals</h2>
            <br />
            <p>
              If shopping is an issue, keep your pantry stocked with foods that will last a long time. If you have some long-lasting staples on hand, it’ll be easier to make a healthy meal. Some good items to stock up on include:
              <br /><br />
              &diams; canned fruit and canned and UHT fruit juice
              <br />
              &diams; canned vegetables (reduced salt where possible)
              <br />
              &diams; baked beans and bean mixes
              <br />
              &diams; rice, spaghetti, pasta, flour, rolled oats and breakfast cereals
              <br />
              &diams; canned, powdered and reduced fat UHT milk and custard
              <br />
              &diams; canned meat and fish
              <br />
              &diams; canned soups
              <br />
              &diams; sauces (such as reduced salt soy sauce) and pastes (such as reduced salt peanut butter)
              <br />
              &diams; vegetable oil such as olive oil or canola oil.
              <br /><br />
              <h5>You may like to try these simple meal and snack options too:</h5>
              <br />
              &diams; grilled or baked chicken, bread and butter or margarine, plus canned fruit and custard
              <br />
              &diams; a piece of grilled fish and a garden salad, plus a tub of fruity yoghurt
              <br />
              &diams; shepherd’s pie with chopped cooked vegetables, plus a fruit salad
              <br />
              &diams; baked beans or spaghetti on toast, plus a glass of milk and a banana
              <br />
              &diams; toast with peanut butter (or another nut butter) and banana, plus some frozen yoghurt
              <br />
              &diams; cheesy scrambled eggs or an omelette, with grilled tomatoes and mushrooms
              <br />
              &diams; a boiled egg with toast, plus a glass of milk and some fresh fruit
              <br />
              &diams; thick, hearty canned soup with a bread roll, plus fruit and custard
              <br />
              &diams; a slice of quiche with salad or chopped cooked vegetables, plus fresh fruit and yoghurt
              <br />
              &diams; cottage cheese and canned fruit
              <br />
              &diams; smoothies made with milk, yoghurt or ice-cream and fruit
              <br />
              &diams; sardines or tuna on toast
              <br />
              &diams; cheese and crackers.
              <br /><br />
              Better Health Channel has more good information on eating for life stages, healthy and active ageing, and maintaining a healthy mind with age.
            </p>
          </section>
          <br />
          <section id='link5'>
            <h2>5. Remember…</h2>
            <br/>
            <p>
              &diams; As you become older, the foods and drinks that make up a healthy diet for you may be slightly different from when you were younger.
              <br /><br />
              &diams; The Australian Dietary Guidelines outline specific nutritional needs for older people.
              <br/><br/>
              &diams; Know serving sizes and amounts for your age.
              <br /><br />
              &diams; If you need help choosing or preparing a healthy diet, chat to a family member, your healthcare professional, carer or an accredited practising dietitian.
              <br /><br />
              &diams; Talk to your doctor about your specific health needs.
            </p>
          </section>
          <br />
          <section id='link6'>
            <h2>6. Where to get help</h2>
            <br />
            <p>
              &diams; Your GP (doctor)<br /><br />
              &diams; Your pharmacist<br /><br />
              &diams; Your carer<br /><br />
              &diams; Dietitians Association of Australia. Tel. 1800 812 942<br /><br />
              &diams; Nutrition Australia. Tel. (03) 8431 5800<br /><br />
            </p>
          </section>
          <div align="right"> <a href='#top'>Go to top</a></div>

        </div>
        <div>
          <Link to='/customer'>Back to Dash Board</Link>
        </div>
      </div>
    </div>

  );
};

export default Nutrition;
